import os
print(os.path.abspath('test4.py'))
print()
path = 'D:/test'
print(os.path.exists('D:/講義'))